create function getpassword(par_pwd character varying) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_pwd text;
  begin
     select into loc_pwd password from account where username = par_usr;
     if loc_pwd isnull then
       loc_pwd = 'null';
     end if;
     return loc_pwd;
 end;
$$;

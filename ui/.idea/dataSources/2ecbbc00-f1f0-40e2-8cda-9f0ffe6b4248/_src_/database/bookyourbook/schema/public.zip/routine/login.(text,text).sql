create function login(par_username text, par_password text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	loc_username TEXT;
	loc_password TEXT;
	loc_res      TEXT;
BEGIN
			SELECT INTO loc_username "username", loc_password "password" FROM account WHERE username = par_username AND password = par_password;
				IF loc_username ISNULL AND loc_password ISNULL THEN
									loc_res = 'Error Username or password';
				ELSE
									loc_res = 'ok';
				END IF;
				RETURN loc_res;
END;
$$;

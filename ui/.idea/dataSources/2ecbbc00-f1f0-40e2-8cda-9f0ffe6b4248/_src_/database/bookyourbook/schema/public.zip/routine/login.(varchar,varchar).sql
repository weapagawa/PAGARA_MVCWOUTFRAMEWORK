create function login(par_user character varying, par_pass character varying) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_usr VARCHAR;
    loc_pwd VARCHAR;
    loc_res VARCHAR;
  begin
     select into loc_usr account.username from account
       where account.username = par_user and account.password = par_pass;

     if loc_usr isnull then
       loc_res = 'Error';
     else
       loc_res = 'ok';
     end if;
     return loc_res;
  end;
$$;

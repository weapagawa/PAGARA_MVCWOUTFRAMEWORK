create function postmyad1(bk_nm text, bk_desc text, bk_price integer, bk_cat text, bk_photo text, bk_det text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_bknm text;
    loc_bkdesc text;
    loc_bkpr text;
    loc_bkcat text;
    loc_bkph text;
    loc_bkdet text;
  begin
    select into loc_bknm book_name, loc_bkdesc description, loc_bkpr price, loc_bkcat category, loc_bkph photo, loc_bkdet details from books;
     if bk_nm NOTNULL then

       insert into books (book_name, description, price, category, photo, details) values (bk_nm,bk_desc,bk_price,bk_cat,bk_photo,bk_det);
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;

create function displaymodal_one(OUT text, OUT integer) returns SETOF record
LANGUAGE SQL
AS $$
select book_name, price from books;
$$;

create function editmyad1(ebk_nm text, ebk_desc text, ebk_price integer, ebk_cat text, ebk_photo text, ebk_det text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_ebknm text;
    loc_ebkdesc text;
    loc_ebkpr int;
    loc_ebkcat text;
    loc_ebkph text;
    loc_ebkdet text;
  begin
     select into loc_ebknm book_name, loc_ebkdesc decsription, loc_ebkpr price, loc_ebkcat category, loc_ebkph photo, loc_ebkdet details from books;
     if loc_ebknm NOTNULL then

       UPDATE books set book_name = ebk_nm,  description = ebk_desc, price = ebk_price, category = ebk_cat, photo = ebk_photo, details = ebk_det where book_id = 1;
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;

create function postmyprof(p_fname text, p_lname text, p_add text, p_mobile integer, p_email text, p_web text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_fname text;
    loc_lname int;
    loc_add text;
    loc_mobile int;
    loc_email text;
    loc_web text;
  begin
    select into loc_fname firstname, loc_lname lastname, loc_add address, loc_mobile mobile, loc_email email, loc_web weblink from profile;
     if p_fname NOTNULL then

       insert into profile(firstname, lastname, address, mobile, email, weblink) values (p_fname,p_lname,p_add,p_mobile,p_email,p_web);
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;

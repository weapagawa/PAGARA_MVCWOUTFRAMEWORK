create function display_rent(OUT text, OUT text, OUT text, OUT integer, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select firstname, lastname, address, mobile, email, weblink from profile;
$$;

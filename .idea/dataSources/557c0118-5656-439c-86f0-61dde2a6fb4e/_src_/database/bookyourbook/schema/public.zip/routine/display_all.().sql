create function display_all(OUT text, OUT text, OUT integer, OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select book_name, description, price, category, photo, details from books ORDER BY book_id;
$$;
